package edu.montana.csci.csci468.demo;
import edu.montana.csci.csci468.CatscriptTestBase;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class PartnerTests extends CatscriptTestBase {

    @Test
    void PartnerTest1() {
        assertEquals("42\n", executeProgram("var x : int = 6\n" + "print(x * (x+1))"));

    }

@Test
    void PartnerTest2(){
        assertEquals("13\n", executeProgram("function foo() : int { return 3}\n" + "function boop()" +
                " : int { return 10 }\n"+ "print(foo() + boop())"));

    }
    @Test
    void PartnerTest3(){
        assertEquals("1\n2\n3\n4\n5\n6\n7\n8\n9\n", executeProgram("for(x in [[1,2,3],[4,5,6],[7,8,9]]){" +
                "for(i in x){ print(i)}}"));
    }
}